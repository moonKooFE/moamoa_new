export const API = {
    baseURL: "http://52.201.207.3:8090/",
    limit: 10, // 최대 로딩 페이지(페이지 로딩 단위)
    startPage: 0 // 시작 페이지
  };
  