export const pageEffect = {
    initial: {
        position: 'relative',
        left: '100%'
    },
    in: {
        position: 'relative',
        left: '0%'
    },
    out: {
        position: 'relative',
        left: '100%'
    }
  };